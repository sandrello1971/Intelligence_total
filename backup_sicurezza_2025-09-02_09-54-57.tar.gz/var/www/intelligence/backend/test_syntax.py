import ast; ast.parse(open('app/main.py').read()); print('✅ Sintassi corretta' app/services/web_scraping/api_routes_working.py)
