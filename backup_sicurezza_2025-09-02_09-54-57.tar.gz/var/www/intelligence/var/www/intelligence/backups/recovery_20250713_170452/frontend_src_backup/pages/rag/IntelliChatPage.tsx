import React from 'react';
import IntelliChat from '../../components/admin/IntelliChat';

const IntelliChatPage: React.FC = () => {
  return <IntelliChat />;
};

export default IntelliChatPage;
