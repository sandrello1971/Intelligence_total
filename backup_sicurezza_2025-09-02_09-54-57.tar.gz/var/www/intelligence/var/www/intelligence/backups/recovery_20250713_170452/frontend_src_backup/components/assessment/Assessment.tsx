import React from 'react';

const Assessment: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900">📊 Assessment</h1>
      <p className="text-gray-600 mt-2">Sistema assessment</p>
    </div>
  );
};

export default Assessment;
